var playerColors = [
    {
        name: "red",
        hue: 0,
    },
    {
        name: "orange",
        hue: 30,
    },
    {
        name: "yellow",
        hue: 70,
    },
    {
        name: "green",
        hue: 100,
    },
    {
        name: "cyan",
        hue: 180,
    },
    {
        name: "blue",
        hue: 220,
    },
    {
        name: "purple",
        hue: 270,
    },
    {
        name: "pink",
        hue: 330,
    }
]